<?php

return [
    'en' => 'English',
    'ar' => 'Arabic',
    'no' => 'Norway',
    'de' => 'German',
];
