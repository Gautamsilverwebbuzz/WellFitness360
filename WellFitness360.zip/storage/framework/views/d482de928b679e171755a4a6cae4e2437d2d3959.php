
<div class="col-md-3 left_col">
	<div class="left_col scroll-view">
		<div class="navbar nav_title" style="border: 0;">
			<a href="<?php echo e(route('/admin/dashboard')); ?>" class="site_title"><i class="fa fa-paw"></i> <span>WellFit360</span></a>
		</div>
		<div class="clearfix"></div>
		<!-- menu profile quick info -->
		<div class="profile clearfix">
			<div class="profile_pic">
				<img src="<?php echo e(asset('backend/images/img.jpg')); ?>" alt="logo" class="img-circle profile_img">
			</div>
			<div class="profile_info">
				<span>Welcome,</span>
				<h2><?php echo e((Auth::user()) ? (Auth::user()->name).' '.(Auth::user()->sur_name) : ''); ?></h2>
			</div>
		</div>
		<!-- /menu profile quick info -->
		<br />
		<!-- sidebar menu -->
		
		<?php if(Auth::user()->role_id === 1): ?>
		<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
			<div class="menu_section">
				<h3>General</h3>
				<ul class="nav side-menu">
					<li class="<?php echo e((request()->is('/admin/dashboard'))? 'current-page': ''); ?>">
						<a href="<?php echo e(route('/admin/dashboard')); ?>"><i class="fa fa-home"></i><?php echo app('translator')->get('backend/sidebar.home'); ?></a>
					</li>
					
					<li class="<?php echo e((request()->is('UserManagement') || (request()->is('UserManagement/create') ||(request()->is('UserManagement/*/edit'))))? 'current-page': ''); ?>">
						<a href="<?php echo e(route('UserManagement.index')); ?>">
						<i class="fa fa-user"></i><?php echo app('translator')->get('backend/sidebar.user_management'); ?>
						</a>
					</li>
					
					<li class="<?php echo e((request()->is('trainerManagement') || (request()->is('trainerManagement/create') ||(request()->is('trainerManagement/*/edit'))))? 'current-page': ''); ?>">
						<a href="<?php echo e(route('trainerManagement.index')); ?>">
						<i class="fa fa-user"></i><?php echo app('translator')->get('backend/sidebar.trainner_management'); ?>
						</a>
					</li>

					
					<li class="<?php echo e((request()->is('categoriesManagement') || (request()->is('categoriesManagement/create') ||(request()->is('categoriesManagement/*/edit'))))? 'active': ''); ?>">
						<a><i class="fa fa-list-alt"></i>
						<?php echo app('translator')->get('backend/sidebar.categories'); ?>
						<span class="fa fa-chevron-down"></span>
						</a>
						<ul class="nav child_menu" style="<?php echo e((request()->is('categoriesManagement')) || (request()->is('subcategoriesManagement')) ? 'display:block': ''); ?>">
							<li class="<?php echo e((request()->is('categoriesManagement')) ? 'current-page': ''); ?>">
								<a href="<?php echo e(route('categoriesManagement.index')); ?>"><?php echo app('translator')->get('backend/sidebar.categories_management'); ?></a>
							</li>
							<li class="<?php echo e((request()->is('subcategoriesManagement')) ? 'current-page': ''); ?>">
								<a href="<?php echo e(route('subcategoriesManagement.index')); ?>"><?php echo app('translator')->get('backend/sidebar.sub_categories_management'); ?></a>
							</li>
						</ul>
					</li>
					
					
					<li class="<?php echo e((request()->is('trainercategoriesManagement') || (request()->is('trainercategoriesManagement/create') ||(request()->is('trainercategoriesManagement/*/edit'))))? 'current-page': ''); ?>">
						<a href="<?php echo e(route('trainercategoriesManagement.index')); ?>">
						<i class="fa fa-list-alt"></i><?php echo app('translator')->get('backend/sidebar.trainer_categories_management'); ?>
						</a>
					</li>
					
					<li class="<?php echo e((request()->is('eventManagement') || (request()->is('eventManagement/create') ||(request()->is('eventManagement/*/edit'))))? 'current-page': ''); ?>">
						<a href="<?php echo e(route('eventManagement.index')); ?>">
						<i class="fa fa-calendar-check-o"></i><?php echo app('translator')->get('backend/sidebar.event_management'); ?>
						</a>
					</li>
					<li class="<?php echo e((request()->is('SubscriptionPlanManagement') || (request()->is('SubscriptionPlanManagement/create') ||(request()->is('SubscriptionPlanManagement/*/edit'))))? 'current-page': ''); ?>">
						<a href="<?php echo e(route('SubscriptionPlanManagement.index')); ?>">
						<i class="fa fa-list-ul"></i><?php echo app('translator')->get('backend/sidebar.subscriptionplan_management'); ?>
						</a>
					</li>
					<li class="<?php echo e((request()->is('user-trainer-activity') || (request()->is('user-trainer-activity/create') ||(request()->is('user-trainer-activity/*/edit'))))? 'current-page': ''); ?>">
						<a href="<?php echo e(route('user-trainer-activity')); ?>">
						<i class="fa fa-tasks" aria-hidden="true"></i><?php echo app('translator')->get('backend/sidebar.user_trainer_activty'); ?>
						</a>
					</li>
					
					<li class="<?php echo e((request()->is('FeesManagement') || (request()->is('FeesManagement/create') ||(request()->is('FeesManagement/*/edit'))))? 'current-page': ''); ?>">
						<a href="<?php echo e(route('FeesManagement.index')); ?>">
						<i class="fa fa-money" aria-hidden="true"></i><?php echo app('translator')->get('backend/sidebar.fees_management'); ?>
						</a>
					</li>
					
					<li class="">
						<a href="<?php echo e(route('E_shopManagement.index')); ?>">
						<i class="fa fa-shopping-basket"></i><?php echo app('translator')->get('backend/sidebar.e_shop_management'); ?>
						</a>
					</li>
					
					<li class="">
						<a href="<?php echo e(route('blogManagement.index')); ?>">
						<i class="fa fa-newspaper-o"></i><?php echo app('translator')->get('backend/sidebar.blog_management'); ?>
						</a>
					</li>
					
					<li class="<?php echo e((request()->is('module') || (request()->is('module/create') ||(request()->is('module/*/edit')))) ||
						(request()->is('rolepermission') || (request()->is('rolepermission/create') ||(request()->is('rolepermission/*/edit')) )) ? 'active': ''); ?>">
						<a><i class="fa fa-file"></i>
						<?php echo app('translator')->get('backend/sidebar.cms_pages'); ?>
						<span class="fa fa-chevron-down"></span>
						</a>
						<ul class="nav child_menu" style="<?php echo e((request()->is('cms_aboutus')) || (request()->is('cms_contactus')) ? 'display:block': ''); ?>">
							<li class="<?php echo e((request()->is('module')) ? 'current-page': ''); ?>">
								<a href="<?php echo e(route('cms_aboutus')); ?>"><?php echo app('translator')->get('backend/sidebar.about_us'); ?></a>
							</li>
							<li class="<?php echo e((request()->is('cms_contactus')) ? 'current-page': ''); ?>">
								<a href="<?php echo e(route('cms_contactus')); ?>"><?php echo app('translator')->get('backend/sidebar.contact_us'); ?></a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e((request()->is('setting')) ? 'current-page': ''); ?>">
						<a href="<?php echo e(route('setting')); ?>">
						<i class="fa fa-cog"></i><?php echo app('translator')->get('backend/sidebar.setting'); ?>
						</a>
					</li>
				</ul>
			</div>
		</div>
		<?php endif; ?>
		
		
		<?php if(Auth::user()->role_id === 2): ?>
		<?php endif; ?>
		
		
		<?php if(Auth::user()->role_id === 3): ?>
		<?php endif; ?>
		
		<!-- /sidebar menu -->
		<!-- /menu footer buttons -->
		<div class="sidebar-footer hidden-small">
			<a data-toggle="tooltip" data-placement="top" title="Settings">
			<span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
			</a>
			<a data-toggle="tooltip" data-placement="top" title="FullScreen">
			<span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
			</a>
			<a data-toggle="tooltip" data-placement="top" title="Lock">
			<span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
			</a>
			<a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo e(route('/admin/logout')); ?>">
			<span class="glyphicon glyphicon-off" aria-hidden="true"></span>
			</a>
		</div>
		<!-- /menu footer buttons -->
	</div>
</div><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/templates/sidebar.blade.php ENDPATH**/ ?>