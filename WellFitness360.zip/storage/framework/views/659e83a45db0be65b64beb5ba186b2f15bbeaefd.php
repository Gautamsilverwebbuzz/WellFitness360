

<?php $__env->startSection('content'); ?>

<div class="main_container">
    <?php echo $__env->make('backend.templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- top navigation -->
    <?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /top navigation -->

    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
          </div>
          <div class="clearfix"></div>
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2><?php echo app('translator')->get('backend/list.forms.contact_us_content'); ?></h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                  <?php if(session()->has('success_msg')): ?>
                  <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('success_msg')); ?>

                  </div>
                  <?php endif; ?>

                  <?php if(session()->has('error_msg')): ?>
                  <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('error_msg')); ?>

                  </div>
                  <?php endif; ?>
                </div>
                <div class="x_content">
                  <br />
                  <form id="contactUsForm" action="<?php echo e(route('cms_contactus')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal form-label-left">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?> ">
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo app('translator')->get('backend/list.forms.email'); ?><span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                            <input type="email" name="Email" value="<?php if(isset($contact_us->Email) && !empty($contact_us->Email)): ?><?php echo e($contact_us->Email); ?><?php endif; ?>" class="form-control has-feedback-left" placeholder="Email">
                            <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
                            <small class="text-danger"><?php echo e($errors->first('Email')); ?></small>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo app('translator')->get('backend/list.forms.contact_no'); ?><span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                            <input type="text" name="ContactNumber" value="<?php if(isset($contact_us->ContactNumber) && !empty($contact_us->ContactNumber)): ?><?php echo e($contact_us->ContactNumber); ?><?php endif; ?>" maxlength="10" class="form-control" placeholder="Enter contact number">
                            <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
                            <small class="text-danger"><?php echo e($errors->first('ContactNumber')); ?></small>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-3"><?php echo app('translator')->get('backend/list.forms.telephone_no'); ?></label>
                        <div class="col-md-6 col-sm-6 col-xs-6">
                            <input type="text" name="Telephone" value="<?php if(isset($contact_us->Telephone) && !empty($contact_us->Telephone)): ?><?php echo e($contact_us->Telephone); ?><?php endif; ?>"  class="form-control" data-inputmask="'mask' : '(999) 999-9999'">
                            <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                            <small class="text-danger"><?php echo e($errors->first('Telephone')); ?></small>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo app('translator')->get('backend/list.forms.website'); ?><span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="text" name="Website" value="<?php if(isset($contact_us->Website) && !empty($contact_us->Website)): ?><?php echo e($contact_us->Website); ?><?php endif; ?>" id="title" class="form-control col-md-7 col-xs-12" placeholder="Enter title">
                            <small class="text-danger"><?php echo e($errors->first('Website')); ?></small>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo app('translator')->get('backend/list.forms.address'); ?><span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <textarea name="Address" class="form-control" rows="3" placeholder="Enter address"><?php if(isset($contact_us->Address) && !empty($contact_us->Address)): ?><?php echo e($contact_us->Address); ?><?php endif; ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo app('translator')->get('backend/list.forms.description'); ?><span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <textarea name="Description" class="resizable_textarea form-control" placeholder="Enter description"><?php if(isset($contact_us->Description) && !empty($contact_us->Description)): ?><?php echo e($contact_us->Description); ?><?php endif; ?></textarea>
                        </div>
                    </div>
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                        <button class="btn btn-primary" type="button" onclick="window.history.go(-1); return false;">Cancel</button>
                        <button type="submit" class="btn btn-success">Submit</button>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /footer content -->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/cmsPages/contact_us.blade.php ENDPATH**/ ?>