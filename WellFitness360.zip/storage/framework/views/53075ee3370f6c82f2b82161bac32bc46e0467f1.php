<?php echo $__env->make('auth.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div>
	  <a class="hiddenanchor" id="signup"></a>
	  <a class="hiddenanchor" id="signin"></a>

	  <div class="login_wrapper">
		<div class="animate form login_form">
		  <section class="login_content">
			<?php if(session()->has('success_msg')): ?>
			<div class="alert alert-success">
				<?php echo e(session()->get('success_msg')); ?>

			</div>
			<?php endif; ?>
			<?php if(session()->has('error_msg')): ?>
			<div class="alert alert-danger">
				<?php echo e(session()->get('error_msg')); ?>

			</div>
			<?php endif; ?>
			<form id="login" method="POST">
				<input type="hidden" name="_token"  id="csrf-token" value="<?php echo e(csrf_token()); ?>">
				<h1>Login</h1>
				<div class="auth-input">
					<input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email Address" required="" />
				</div>
				<div class="auth-input">
					<input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" required="" />
				</div>
				<div class="auth-input">
					
					<button type="submit" class="btn btn btn-success login-btn">Login</button>
					<a class="reset_pass" href="<?php echo e(route('/admin/forgetPassword')); ?>">Forgot password?</a>
					
					
				</div>

				<div class="clearfix"></div>

				<div class="separator">
					<p class="change_link">New to site?
					<a href="#signup" class="to_register"> Create Account </a>
					</p>

					<div class="clearfix"></div>
					<br />

					<div>
					<h1><i class="fa fa-paw"></i> WellFit360</h1>
					<p>©2020 All Rights Reserved.</p>
					</div>
				</div>
			</form>
		  </section>
		</div>

		<div id="register" class="animate form registration_form">
		  <section class="login_content">
			<form id="registerForm" name="register" method="POST">
				<input type="hidden" name="_token" id="csrf-tokens" value="<?php echo e(csrf_token()); ?>">
				<h1>Create Account</h1>
				<div style="padding-bottom: 20px;">
					<select class="form-control" name="roles">
						<option>Register Type</option>
						<?php if($roles): ?>
							<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($role['id']); ?>"><?php echo e(ucfirst($role['role_name'])); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</select>
					<small class="text-danger"><?php echo e($errors->first('roles')); ?></small>
				</div>
				<div class="auth-input">
					<small class="text-danger"><?php echo e($errors->first('name')); ?></small>
					<input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="User Name" />
				</div>
				<div class="auth-input">
					<small class="text-danger"><?php echo e($errors->first('surname')); ?></small>
					<input type="text" name="surname" value="<?php echo e(old('surname')); ?>" class="form-control" placeholder="Surname" />
				</div>
				<div class="auth-input">
					<small class="text-danger"><?php echo e($errors->first('email')); ?></small>
					<input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Email" id="emailaddress"/>
				</div>
				<div class="auth-input">
					<small class="text-danger"><?php echo e($errors->first('contact_no')); ?></small>
					<input type="text" name="contact_no" value="<?php echo e(old('contact_no')); ?>" class="form-control" placeholder="Contact No" maxlength="10" />
				</div>
				<div class="auth-input">
					<small class="text-danger"><?php echo e($errors->first('password')); ?></small>
					<input type="password" name="password" value="" class="form-control" placeholder="Password" />
				</div>
				<div class="form-group">
	                <label class="control-label col-md-3 col-sm-3 col-xs-12">Gender</label>
	                <div class="col-md-6 col-sm-6 col-xs-12">
	                    <div id="gender" class="btn-group" data-toggle="buttons">
	                        <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
	                        <input type="radio" name="gender" value="Male" data-parsley-multiple="gender" class="error"> &nbsp; Male &nbsp;
	                        </label>
	                        <label class="btn btn-primary" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
	                        <input type="radio" name="gender" value="Female" data-parsley-multiple="gender" class="error"> Female
	                        </label>
	                    </div>
	                    <small class="text-danger"></small>
	                </div>
	                <div class="gender-cls"><label id="gender-error" class="error" for="gender"></label></div>
	            </div>
				<div>
					
					<input type="submit" name="register" value="Submit" class="btn btn-success">
				</div>

				<div class="clearfix"></div>

				<div class="separator">
					<p class="change_link">Already a member ?
					<a href="#signin" class="to_register"> Log in </a>
					</p>

					<div class="clearfix"></div>
					<br />

					<div>
					<h1><i class="fa fa-paw"></i> WellFit360</h1>
					<p>©2020 All Rights Reserved.</p>
					</div>
				</div>
			</form>
		  </section>
		</div>
	  </div>
	</div>
<?php echo $__env->make('auth.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/auth/login.blade.php ENDPATH**/ ?>