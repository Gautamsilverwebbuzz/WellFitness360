<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- CSRF Token -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<title><?php echo e(config('app.name', 'WellFit360')); ?></title>
	<link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" type="text/css">
	<!-- <link rel="stylesheet" href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>" type="text/css"> -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/toastr/toastr.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>" type="text/css">
	<script>
		var BASE_URL = "<?php echo e(URL::to('/')); ?>";
	</script>
</head>
<body>
	<div id="cover-spin"></div>
	<?php echo $__env->yieldContent('content'); ?>
  	<script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
  	<script src="<?php echo e(asset('frontend/js/jquery.validate.min.js')); ?>"></script>
  	<script src="<?php echo e(asset('frontend/js/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/js/frontend.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/Frontend/layouts/app.blade.php ENDPATH**/ ?>