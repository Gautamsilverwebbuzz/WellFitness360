
<?php $__env->startSection('content'); ?>
<div class="main_container">
	<?php echo $__env->make('backend.templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- top navigation -->
	<?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- /top navigation -->
	<!-- page content -->
	<div class="right_col" role="main">
		<div class="">
		</div>
		<div class="clearfix"></div>
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="x_panel">
					<div class="x_title">
						<h2><?php echo app('translator')->get('backend/list.forms.edit_fees'); ?></h2>
						<ul class="nav navbar-right panel_toolbox">
							<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
							</li>
							<li class="dropdown">
								<a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
								<ul class="dropdown-menu" role="menu">
									<li><a href="javascript:void(0);">Settings 1</a>
									</li>
									<li><a href="javascript:void(0);">Settings 2</a>
									</li>
								</ul>
							</li>
							<li><a class="close-link"><i class="fa fa-close"></i></a>
							</li>
						</ul>
						<div class="clearfix"></div>
					</div>
					<div class="x_content">
						<br />
						<form id="feesForm" action="<?php echo e(route('FeesManagement.update',$fees['ID'])); ?>"  method="post" class="form-horizontal form-label-left">
							<?php echo e(method_field('PUT')); ?>

							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?> ">
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12">Trainer</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<select id="trainername" name="trainername" class="form-control">
										<option value="">Select Trainer</option>
										<?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($trainer['id']); ?>" <?php if($fees['TrainerID'] == $trainer['id']): ?> selected <?php endif; ?>><?php echo e(ucfirst($trainer['name'])); ?> <?php echo e(ucfirst($trainer['sur_name'])); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<small class="text-danger"><?php echo e($errors->first('trainername')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12" for="trainerfee">TrainerFee <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<input type="text" id="trainerfee" name="trainerfee" value="<?php echo e($fees['TrainerFee']); ?>" class="form-control col-md-7 col-xs-12" placeholder="Enter TrainerFee">
									<small class="text-danger"><?php echo e($errors->first('trainerfee')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label for="admidfee" class="control-label col-md-3 col-sm-3 col-xs-12">AdminFee</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<input type="text" name="admidfee" value="<?php echo e($fees['AdminFee']); ?>" id="admidfee" class="form-control col-md-7 col-xs-12" placeholder="Enter AdmidFee">
									<small class="text-danger"><?php echo e($errors->first('admidfee')); ?></small>
								</div>
							</div>
							<div class="ln_solid"></div>
							<div class="form-group">
								<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
									<button type="submit" class="btn btn-success">Submit</button>
									<button class="btn btn-primary" type="button" onclick="window.history.go(-1); return false;"><?php echo app('translator')->get('backend/list.forms.back'); ?></button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /page content -->
<!-- footer content -->
<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /footer content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/FeesManagement/edit.blade.php ENDPATH**/ ?>