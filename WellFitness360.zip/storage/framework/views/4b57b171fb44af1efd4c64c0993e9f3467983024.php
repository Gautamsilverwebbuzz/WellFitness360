

<?php $__env->startSection('content'); ?>

<div class="main_container">
    <?php echo $__env->make('backend.templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- top navigation -->
    <?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /top navigation -->

    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
          </div>
          <div class="clearfix"></div>
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2><?php echo app('translator')->get('backend/list.forms.about_us_content'); ?></h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                  <?php if(session()->has('success_msg')): ?>
                  <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('success_msg')); ?>

                  </div>
                  <?php endif; ?>

                  <?php if(session()->has('error_msg')): ?>
                  <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('error_msg')); ?>

                  </div>
                  <?php endif; ?>
                </div>
                <div class="x_content">
                  <br />
                  <form id="aboutUsForm" action="<?php echo e(route('cms_aboutus')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal form-label-left">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?> ">
                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo app('translator')->get('backend/list.forms.title'); ?><span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text" name="Title" value="<?php if(isset($about_us->Title) && !empty($about_us->Title)): ?><?php echo e($about_us->Title); ?><?php endif; ?>" id="title" class="form-control col-md-7 col-xs-12" placeholder="Enter title">
                        <small class="text-danger"><?php echo e($errors->first('Title')); ?></small>
                      </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo app('translator')->get('backend/list.forms.short_description'); ?><span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <textarea name="ShortDescription" class="form-control" rows="3" placeholder="Enter short description"><?php if(isset($about_us->ShortDescription) && !empty($about_us->ShortDescription)): ?><?php echo e($about_us->ShortDescription); ?><?php endif; ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo app('translator')->get('backend/list.forms.long_description'); ?><span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <textarea name="LongDescription" class="form-control" rows="3" placeholder="Enter long description"><?php if(isset($about_us->LongDescription) && !empty($about_us->LongDescription)): ?><?php echo e($about_us->LongDescription); ?><?php endif; ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo app('translator')->get('backend/list.forms.image'); ?><span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="file" name="Image" value="" id="about-us-image" class="form-control col-md-7 col-xs-12" placeholder="Select image">
                          <small class="text-danger"><?php echo e($errors->first('image')); ?></small>
                        </div>
                      </div>
                      <div class="form-group image_preview">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <img id="ImagePreview" src="<?php if(isset($about_us->Image)): ?><?php echo e(asset($about_us->Image)); ?><?php endif; ?>" alt="No image uploaded" height="100px"/ >
                        </div>
                      </div>

                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                        <button type="submit" class="btn btn-success">Submit</button>
                        <button class="btn btn-primary" type="button" onclick="window.history.go(-1); return false;"><?php echo app('translator')->get('backend/list.forms.back'); ?></button>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /footer content -->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/cmsPages/about_us.blade.php ENDPATH**/ ?>