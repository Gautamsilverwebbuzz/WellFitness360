<!--Navbar -->
<div class="container-fluid main-header">
	<nav class=" navbar navbar-expand-lg navbar-dark">
		<a class="navbar-brand font-bold" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt="logo"></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarSupportedContent-4">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item ">
					<a class="nav-link" href="javascript:void(0);"><i class="fa fa-envelope"></i> Sign In </a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo e(url('login')); ?>"><i class="fa fa-gear"></i> Log In</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="javascript:void(0);"><i class="fa fa-gear"></i> For Trainers</a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="javascript:void(0);"><i class="fa fa-gear"></i> Unleash Your Power</a>
				</li>
				<!-- <li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user"></i> For Trainers </a>
					<div class="dropdown-menu dropdown-menu-right dropdown-cyan" aria-labelledby="navbarDropdownMenuLink-4">
						<a class="dropdown-item" href="#">My account</a>
						<a class="dropdown-item" href="#">Log out</a>
					</div>
					</li> -->
			</ul>
		</div>
	</nav>
</div>
<!--/.Navbar --><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/Frontend/layouts/header.blade.php ENDPATH**/ ?>