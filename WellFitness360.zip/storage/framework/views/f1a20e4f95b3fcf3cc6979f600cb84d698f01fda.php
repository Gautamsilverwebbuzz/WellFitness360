
<?php $__env->startSection('content'); ?>
<div class="main_container">
	<?php echo $__env->make('backend.templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- top navigation -->
	<?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- /top navigation -->
	<!-- page content -->
	<div class="right_col" role="main">
		<div class="">
		</div>
		<div class="clearfix"></div>
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="x_panel">
					<div class="x_title">
						<h2><?php echo app('translator')->get('backend/list.forms.edit_sub_categories'); ?></h2>
						<ul class="nav navbar-right panel_toolbox">
							<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
							</li>
							<li class="dropdown">
								<a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
								<ul class="dropdown-menu" role="menu">
									<li><a href="javascript:void(0);">Settings 1</a>
									</li>
									<li><a href="javascript:void(0);">Settings 2</a>
									</li>
								</ul>
							</li>
							<li><a class="close-link"><i class="fa fa-close"></i></a>
							</li>
						</ul>
						<div class="clearfix"></div>
					</div>
					<div class="x_content">
						<br />
						<form id="editsubcategoreiesForm" action="<?php echo e(route('subcategoriesManagement.update',$subcategories['ID'])); ?>"  method="post" class="form-horizontal form-label-left" enctype='multipart/form-data'>
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?> ">
							<?php echo e(method_field('PUT')); ?>

							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12">Categories</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<select id="categories_name" name="categories_name" class="form-control">
										<option value="">Select Categories</option>
										<?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($val['ID']); ?>" <?php if($subcategories['cat_id'] == $val['ID']): ?> selected <?php endif; ?>><?php echo e($val['cat_Name']); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<small class="text-danger"><?php echo e($errors->first('categories_name')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12" for="sub_categories_name">Sub Categories Name <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<input type="text" name="sub_categories_name" value="<?php echo e($subcategories['Sub_cat_name']); ?>" id="sub_categories_name" class="form-control col-md-7 col-xs-12" placeholder="Enter Categories Name">
									<small class="text-danger"><?php echo e($errors->first('sub_categories_name')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12" for="sub_categories_desc">Sub Categories Description <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<input type="text" id="sub_categories_desc" name="sub_categories_desc" value="<?php echo e($subcategories['Sub_cat_description']); ?>" class="form-control col-md-7 col-xs-12" placeholder="Enter Categories Description">
									<small class="text-danger"><?php echo e($errors->first('sub_categories_desc')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12" for="sub_categories_image">Sub Categories Image <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<input type="file" name="sub_categories_image" id="sub_categories_image" class="form-control col-md-7 col-xs-12">
									<small class="text-danger"><?php echo e($errors->first('sub_categories_image')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12" for="sub_categories_image">
								</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<img src="<?php echo e(asset($subcategories['Sub_cat_image'])); ?>" alt="" width="100px;" height="100px;">
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12" for="workout_time">Workout Time <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<input type="text" name="workout_time" value="<?php echo e($subcategories['workout_time']); ?>" id="workout_time" class="form-control col-md-7 col-xs-12" placeholder="Enter Work Out Time">
									<small class="text-danger"><?php echo e($errors->first('workout_time')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12" for="what_wiil_do">What we Will do?<span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<textarea name="what_wiil_do" id="what_wiil_do" class="form-control col-md-7 col-xs-12" placeholder="Enter What we will do"><?php echo e($subcategories['what_will_do']); ?></textarea>
									<small class="text-danger whatwilldoerror"><?php echo e($errors->first('what_wiil_do')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12" for="equipment">Equipment<span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<input type="text" name="equipment" value="<?php echo e($subcategories['equipment']); ?>" id="equipment" class="form-control col-md-7 col-xs-12" placeholder="Enter Equipment">
									<small class="text-danger"><?php echo e($errors->first('equipment')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12" for="workout_from">WorkOut From<span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<input type="text" name="workout_from" value="<?php echo e($subcategories['workout_from']); ?>" id="workout_from" class="form-control col-md-7 col-xs-12" placeholder="Enter Equipment">
									<small class="text-danger"><?php echo e($errors->first('workout_from')); ?></small>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12">Package</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<select id="package" name="package" class="form-control packagecls">
										<option value="">Select Package</option>
										<option value="free" <?php if($subcategories['package'] == 'free'): ?> selected <?php endif; ?>>Free</option>
										<option value="paid" <?php if($subcategories['package'] == 'paid'): ?> selected <?php endif; ?>>Paid</option>
									</select>
									<small class="text-danger"><?php echo e($errors->first('package')); ?></small>
								</div>
							</div>
							<div class="freevideo">
								<div class="form-group">
									<label class="control-label col-md-3 col-sm-3 col-xs-12" for="video">Video <span class="required">*</span>
									</label>
									<div class="col-md-6 col-sm-6 col-xs-12">
										<input type="file" name="video" id="video" class="form-control col-md-7 col-xs-12">
										<small class="text-danger"><?php echo e($errors->first('video')); ?></small>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3 col-sm-3 col-xs-12">Status</label>
								<div class="col-md-6 col-sm-6 col-xs-12">
									<select id="status" name="status" class="form-control">
										<option value="">Select Status</option>
										<option value="1" <?php if($subcategories['status'] == 1): ?> selected <?php endif; ?>>Active</option>
										<option value="0" <?php if($subcategories['status'] == 0): ?> selected <?php endif; ?>>Inactive</option>
									</select>
									<small class="text-danger"><?php echo e($errors->first('status')); ?></small>
								</div>
							</div>
							<div class="ln_solid"></div>
							<div class="form-group">
								<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
									<button type="submit" class="btn btn-success">Submit</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /page content -->
<!-- footer content -->
<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /footer content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/SubCategoriesManagement/edit_sub_categories.blade.php ENDPATH**/ ?>